// 网站PV/UV统计功能 - 增强版
(function() {
    // 使用Supabase PostgreSQL数据库存储PV数据
    // 该实现不保留localStorage作为备选方案
    
    // 初始化统计数据
    async function initStats() {
        // 等待Supabase客户端初始化完成
        await waitForSupabaseInit();
        
        // 更新PV计数
        await window.SupabaseStats.incrementPV();
        
        // 获取最新统计数据
        const stats = await window.SupabaseStats.getStats();
        
        // 更新页面显示
        updateStatsDisplay(stats.pv);
    }
    
    // 等待Supabase客户端初始化
    function waitForSupabaseInit() {
        return new Promise((resolve) => {
            const checkSupabase = () => {
                if (window.SupabaseStats && window.SupabaseStats.isInitialized()) {
                    resolve();
                } else {
                    setTimeout(checkSupabase, 100);
                }
            };
            
            // 立即检查一次
            checkSupabase();
        });
    }
    
    // 更新统计显示
    function updateStatsDisplay(pv) {
        const statsElement = document.getElementById('site-stats');
        if (statsElement) {
            statsElement.textContent = `已有${formatNumber(pv)}人访问~`;
        }
    }
    
    // 格式化数字，添加千位分隔符
    function formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }
    
    // 当页面加载完成后初始化统计
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initStats);
    } else {
        initStats();
    }
})();