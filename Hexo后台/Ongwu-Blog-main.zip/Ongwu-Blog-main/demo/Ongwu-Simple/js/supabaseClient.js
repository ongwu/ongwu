// Supabase客户端配置和PV/UV统计数据库操作
(function() {
    // 从全局配置中获取Supabase凭据
    // 系统将只使用环境变量提供的配置
    const SUPABASE_CONFIG = window.themeConfig && window.themeConfig.stats && window.themeConfig.stats.supabase || {};
    const SUPABASE_URL = SUPABASE_CONFIG.url || '';
    const SUPABASE_ANON_KEY = SUPABASE_CONFIG.anon_key || '';
    const DEBUG_MODE = SUPABASE_CONFIG.debug || false;
    const RETRY_COUNT = SUPABASE_CONFIG.retry_count || 3;
    const RETRY_INTERVAL = SUPABASE_CONFIG.retry_interval || 1000;
    
    // 检查是否在浏览器环境中
    const isBrowser = typeof window !== 'undefined';
    
    // 初始化Supabase客户端
    let supabaseClient = null;
    
    if (isBrowser && SUPABASE_URL && SUPABASE_ANON_KEY) {
        // 使用动态导入方式加载Supabase客户端库
        async function loadSupabase() {
            try {
                // 动态创建script标签加载Supabase库
                const script = document.createElement('script');
                script.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
                script.onload = () => {
                    // 库加载完成后初始化客户端
                    if (window.supabase) {
                        supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
                    }
                };
                document.head.appendChild(script);
            } catch (error) {
                console.error('Failed to load Supabase client:', error);
            }
        }
        
        loadSupabase();
    }
    
    // 导出Supabase客户端实例和统计相关函数
    window.SupabaseStats = {
        // 初始化数据库表结构
        async initTable() {
            if (!supabaseClient) return;
            
            try {
                // 创建访问统计表（如果不存在）
                const { error } = await supabaseClient.rpc('create_stats_table_if_not_exists');
                if (error) {
                    console.error('Failed to initialize stats table:', error);
                }
            } catch (error) {
                console.error('Error during table initialization:', error);
            }
        },
        
        // 获取当前网站的PV统计数据
        async getStats() {
            if (!supabaseClient) {
                console.error('Supabase client not initialized');
                return {
                    pv: 0
                };
            }
            
            try {
                const { data, error } = await supabaseClient
                    .from('site_stats')
                    .select('pv_count')
                    .single();
                
                if (error) {
                    console.error('Failed to fetch stats:', error);
                    return {
                        pv: 0
                    };
                }
                
                return {
                    pv: data?.pv_count || 0
                };
            } catch (error) {
                console.error('Error fetching stats:', error);
                return {
                    pv: 0
                };
            }
        },
        
        // 更新PV计数
        async incrementPV() {
            if (!supabaseClient) {
                console.error('Supabase client not initialized');
                return;
            }
            
            try {
                await supabaseClient.rpc('increment_pv');
            } catch (error) {
                console.error('Failed to increment PV:', error);
            }
        },
        
        // 检查是否已初始化Supabase客户端
        isInitialized() {
            return !!supabaseClient;
        }
    };
})();