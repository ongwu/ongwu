@echo off

REM 批处理文件用于执行hexo和git命令

echo 开始执行部署命令...

REM 执行hexo命令
echo 执行 hexo g...
hexo g
echo hexo g 命令执行完成

echo 执行 hexo d...
hexo d
echo hexo d 命令执行完成

REM 执行git命令
echo 执行 git add . ...
git add .
echo git add . 命令执行完成

echo 执行 git push -u origin main -f...
git push -u origin main -f
echo git push 命令执行完成

echo 部署命令执行完成