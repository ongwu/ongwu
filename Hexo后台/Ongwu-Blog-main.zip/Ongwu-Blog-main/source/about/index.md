---

title: 关于博主
date: 2025-10-15 01:15:00
author: Ongwu
type: page
---

#### 👋 Hi! I'm Ongwu ，一名技术爱好者和博客作者。
专注于知识分享，希望通过这个博客平台与大家交流技术经验，分享学习心得。

#### 我的项目
| 项目名称 | 项目地址 | 演示地址 | 描述 |
|---------|------------|---------|------|
| Ongwu 笔记 | [访问GitHub](https://github.com/ongwu/Ongwu-Notes) | [访问Demo](https://note.ongwu.cn/) | 个人知识库和学习笔记系统 |
| Ongwu Newmedia | [访问GitHub](https://github.com/ongwu/Ongwu-Newmedia) | [访问Demo](https://www.ongwu.cn/) | 一款专为 Hexo 设计的多媒体知识分享类主题。 |
| Ongwu Simple | [访问GitHub](https://github.com/ongwu/Ongwu-Simple) | [访问Demo](https://www.ongwu.cn/demo/Ongwu-Simple/) | 一个适合Blog的自适应Hexo主题，整体界面简洁大气！ |
| Ongwu Reveal | [访问GitHub](https://github.com/ongwu/Ongwu-Reveal) | [访问Demo](https://www.ongwu.cn/demo/Ongwu-Reveal/) | 一个专为项目展示或作品展示的自适应Hexo主题。 |

#### 关于博客
这个博客创建于 2025 年，旨在分享个人学习笔记和排障经验，帮助更多人解决技术问题，共同进步。如果您有任何问题或建议，欢迎随时联系我！

感谢您的访问！
