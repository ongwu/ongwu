---
categories:
  - 科学技术
date: '2025-11-02T23:09:57.063+08:00'
tags:
  - apt
  - yum
  - get
  - 而
  - install
thumbnail: https://ongwu-img.pages.dev/file/1762096197001_image.jpg
title: "apt-get vs yum：包管理器背后的软件安装战争"
---

!["apt-get vs yum：包管理器背后的软件安装战争"](https://ongwu-img.pages.dev/file/1762096197001_image.jpg)

在现代Linux系统中，软件的安装与管理早已不再是“下载、解压、运行”这样简单粗暴的过程。随着系统复杂性的提升，包管理器（Package Manager）成为了操作系统不可或缺的核心组件。在众多包管理器中，`apt-get` 和 `yum` 分别作为Debian系和Red Hat系的代表，主导了Linux软件分发的格局。尽管它们的目标一致——自动化地安装、更新、配置和删除软件包——但其底层设计哲学、依赖解决机制、生态系统整合方式却大相径庭。这场“软件安装战争”不仅关乎命令行的选择，更深刻反映了两种主流Linux发行路径在系统架构、用户群体和软件分发理念上的差异。

### 一、历史背景与生态定位

`apt-get` 起源于Debian项目，其前身是`dselect`，但真正让Debian系发行版（如Ubuntu、Linux Mint）在开发者中流行的是APT（Advanced Package Tool）工具链，尤其是`apt-get`命令。APT基于`.deb`包格式，使用`dpkg`作为底层包安装工具，而`apt-get`则负责依赖解析、仓库元数据获取和事务性操作。它首次发布于1998年，是早期Linux中少数能自动处理复杂依赖关系的工具之一。

相比之下，`yum`（Yellowdog Updater Modified）是Red Hat系（如CentOS、RHEL、Fedora）的包管理器，诞生于2003年，用于替代功能有限的`up2date`。它基于`.rpm`（Red Hat Package Manager）包格式，由`rpm`命令负责底层安装，而`yum`专注于依赖解析、元数据管理和仓库交互。`yum`的出现，标志着Red Hat生态在自动化软件管理上的重大进步。

两者都诞生于21世纪初，但分别服务于不同的用户群体：APT更受桌面用户和开发者欢迎，而YUM则长期服务于企业服务器环境。这种生态定位差异，直接影响了它们的设计取舍。

### 二、依赖解析机制：智能与稳健的博弈

依赖管理是包管理器的核心挑战。软件包往往依赖其他库、工具或配置文件，若依赖未满足，软件无法正常运行。`apt-get` 和 `yum` 在解决依赖问题上采取了不同的策略。

`apt-get` 使用基于**SAT求解器**的依赖解析算法（在APT 0.8.0后引入，由Debian的`libapt-pkg`库实现）。它会将所有可用包及其依赖关系建模为一个布尔逻辑问题，通过高效的SAT算法寻找最优解。这意味着`apt-get`能处理非常复杂的依赖冲突，例如多个包对同一库的不同版本要求。例如，在Ubuntu 22.04中，安装`docker-ce`可能触发对`containerd.io`、`runc`、`iptables`等多个组件的依赖解析，`apt-get`会自动计算并安装满足所有约束的版本组合。

而`yum` 使用的是**基于图遍历的依赖解析器**（DAG，有向无环图）。它将包和依赖关系建模为图结构，通过拓扑排序确定安装顺序。虽然算法效率较高，但在面对复杂依赖冲突时，`yum`往往需要用户手动干预，例如使用`--skip-broken`或`--nodeps`跳过某些包。例如，在CentOS 7中安装`python3`时，若系统中存在多个Python版本，`yum`可能因依赖冲突而失败，而`apt-get`通常能自动选择兼容版本。

值得注意的是，`yum` 的继承者 `dnf`（Dandified YUM）在Fedora 22后取代了`yum`，引入了基于**libsolv**库的SAT解析器，显著提升了依赖解析能力。这标志着Red Hat系也开始向“智能解析”靠拢，但`yum`在RHEL 7和CentOS 7等长期支持版本中仍广泛使用，因此其局限性仍具现实意义。

### 三、元数据与仓库管理：集中式 vs 分布式

包管理器依赖远程仓库（repository）获取软件包和元数据。`apt-get` 和 `yum` 在仓库管理上的设计差异，反映了其背后的哲学。

`apt-get` 使用**扁平化的仓库结构**。每个仓库包含一个`Packages.gz`文件，列出所有可用包的元信息（如名称、版本、依赖、描述）。用户通过`/etc/apt/sources.list`添加仓库URL，`apt-get update`会下载所有仓库的`Packages.gz`并合并为一个本地数据库。这种设计使得`apt-get`能快速扫描所有来源，支持多源混合使用。例如，Ubuntu用户可同时启用官方仓库、PPA（个人包归档）和第三方镜像，`apt-get`会自动整合这些信息。

而`yum` 使用**层级化的仓库元数据**。每个仓库提供一个`repodata/`目录，内含`primary.xml.gz`、`filelists.xml.gz`、`other.xml.gz`等文件，分别记录包元信息、文件列表和变更日志。`yum`通过`yum makecache`生成本地缓存，但其元数据结构更复杂，解析速度较慢。此外，`yum`对仓库的信任机制更严格，例如默认启用GPG签名验证，且不支持像PPA那样灵活的第三方源。

这种差异导致：`apt-get` 在灵活性和响应速度上占优，适合快速实验和开发；而`yum` 更注重安全性和稳定性，适合企业生产环境。

### 四、事务一致性与系统安全

在软件安装过程中，系统可能因断电、网络中断或依赖冲突而进入不一致状态。包管理器的事务性处理能力至关重要。

`apt-get` 采用**两阶段提交**机制。首先下载所有包并验证签名，然后在本地构建一个“待安装事务”，最后一次性调用`dpkg`执行安装。若中途失败，`dpkg`会保留部分状态，但`apt-get`可通过`apt-get -f install`尝试修复。此外，APT支持`apt-mark hold`锁定特定版本，防止自动升级。

`yum` 则使用**事务日志**（`/var/log/yum.log`）和**RPM数据库**（`/var/lib/rpm`）来追踪变更。它支持事务回滚（需启用`tsflags=test`或`yum history undo`），但默认不记录完整事务历史。直到`dnf`引入`history`命令，Red Hat系才真正实现了与APT相当的回滚能力。

在安全方面，两者都支持GPG签名验证，但`apt-get` 通过`apt-key`管理密钥，而`yum` 依赖仓库配置的`gpgcheck=1`。值得注意的是，APT在Ubuntu中广泛使用**Launchpad密钥服务器**，而RHEL则依赖**Red Hat官方密钥环**，这反映了两者在信任模型上的差异：APT更开放，YUM更封闭。

### 五、用户体验与命令行设计

尽管`apt-get` 和 `yum` 都是命令行工具，但它们的交互体验差异显著。

`apt-get` 命令简洁，但功能有限。例如，`apt-get install`、`remove`、`update`等命令清晰直观。然而，其输出信息较简略，依赖冲突时提示不够友好。为此，Ubuntu开发了`apt`命令（非`apt-get`），提供更现代的输出格式、进度条和更详细的错误信息。例如，`apt install` 会高亮显示将被安装、删除或保留的包。

`yum` 的命令更“冗长”，但信息丰富。例如，`yum install httpd` 会显示详细的依赖树、下载大小和安装后大小。`yum` 还内置了`info`、`search`、`provides`等子命令，支持按功能查找包（如`yum provides */nginx.conf`）。然而，其输出格式较老旧，缺乏现代终端的交互性。

### 六、现实案例：从Docker到Kubernetes的安装对比

以在Ubuntu 20.04和CentOS 7上安装Docker为例：

- **Ubuntu**：  
  ```bash
  sudo apt-get update
  sudo apt-get install docker.io
  ```
  仅需两步，APT自动处理所有依赖（如`containerd`、`runc`、`libseccomp2`），且版本与Ubuntu深度集成。

- **CentOS 7**：  
  ```bash
  sudo yum install -y yum-utils
  sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
  sudo yum install docker-ce docker-ce-cli containerd.io
  ```
  需要手动添加第三方仓库，且依赖解析可能因EPEL与Docker仓库冲突而失败，需手动调整。

这体现了APT在生态整合上的优势，而YUM更依赖用户干预。

### 七、未来趋势：统一还是分化？

随着容器化（如Docker、Podman）和不可变基础设施的兴起，传统包管理器的角色正在被重新定义。但`apt-get` 和 `yum`（及其继承者`dnf`）仍在系统级配置、安全补丁和性能优化中不可替代。

值得注意的是，`apt`（非`apt-get`）和`dnf`正在趋同：两者都支持彩色输出、进度条、更智能的依赖解析和插件扩展。未来，包管理器的“战争”可能不再是命令差异，而是**生态系统整合能力**的竞争——谁能更好地支持CI/CD、安全审计、SBOM（软件物料清单）和云原生部署，谁就能赢得下一个十年。

### 总结

`apt-get` 与 `yum` 的“战争”，本质上是Linux两大生态在软件分发哲学上的碰撞：APT追求灵活、快速、开发者友好，YUM强调稳定、安全、企业级支持。两者在依赖解析、仓库管理、事务处理和安全机制上的差异，反映了其设计目标的深刻分歧。然而，随着`dnf`和`apt`的演进，技术差距正在缩小。对于普通用户而言，选择哪个工具，更多取决于其使用的发行版而非技术优劣。但理解其背后的设计逻辑，能帮助我们更深入地掌控Linux系统，做出更明智的软件管理决策。在软件即服务的时代，包管理器虽小，却是操作系统生命力的关键脉搏。