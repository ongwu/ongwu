---
categories:
  - 科学技术
date: '2025-11-26T16:31:59.599+08:00'
tags:
  - grub
  - GRUB
  - Boot
  - efi
  - sudo
thumbnail: https://ongwu-img.pages.dev/file/1764145906764_image.jpg
title: "双系统启动之谜：GRUB如何决定你的操作系统命运？"
---

!["双系统启动之谜：GRUB如何决定你的操作系统命运？"](https://ongwu-img.pages.dev/file/1764145906764_image.jpg)

**双系统启动之谜：GRUB如何决定你的操作系统命运？**

在现代计算机使用中，双系统（或多系统）配置已成为许多技术用户、开发者和研究人员的常见选择。无论是为了兼容不同软件生态（如Windows与Linux），还是出于性能、安全或开发需求，双系统启动已成为一种实用且高效的解决方案。然而，在按下电源键后，计算机究竟如何“选择”启动哪个操作系统？这个看似简单的过程背后，隐藏着一个关键角色——**GRUB（Grand Unified Bootloader）**。它是操作系统启动的“守门人”，掌控着系统启动的“命运”。本文将深入解析GRUB的工作原理、配置逻辑、故障排查机制，并揭示其在多系统环境中的核心作用。

---

### 一、启动流程的起点：从BIOS/UEFI到GRUB

计算机启动是一个分阶段的复杂过程。在按下电源键后，首先由**固件**（Firmware）接管，即传统的**BIOS**（Basic Input/Output System）或现代的**UEFI**（Unified Extensible Firmware Interface）。UEFI相比BIOS具有更强大的功能，如支持图形界面、更大的硬盘分区（GPT）、安全启动（Secure Boot）等。

在UEFI模式下，系统会加载**EFI系统分区**（ESP）中的引导程序。如果安装了双系统，例如Windows和Linux，Windows通常会在ESP中安装自己的引导程序（如`bootmgfw.efi`），而Linux安装时会将**GRUB**安装到ESP中，并设置为默认引导加载器。此时，GRUB成为“主引导程序”，负责在启动时展示操作系统选择菜单。

GRUB的核心功能是**加载操作系统的内核**（kernel）和**初始化内存盘**（initramfs），然后将控制权交给操作系统。在双系统环境下，GRUB的作用不仅是加载Linux内核，更重要的是**管理多个操作系统的启动路径**，并允许用户在启动时进行选择。

---

### 二、GRUB的结构与配置：决定“命运”的代码

GRUB并非一个单一程序，而是一组模块化组件，包括：

- **Stage 1**：位于主引导记录（MBR）或EFI分区，负责加载后续阶段。
- **Stage 1.5**（可选）：位于MBR与第一个分区之间的间隙，用于识别文件系统（如ext4、xfs）。
- **Stage 2**：主引导程序，加载配置文件，显示启动菜单。
- **GRUB模块**：动态加载的代码，支持文件系统、加密、网络等扩展功能。

在Linux系统中，GRUB的主配置文件通常为 `/boot/grub/grub.cfg`（在UEFI系统中可能为 `/boot/efi/EFI/[发行版]/grub.cfg`）。然而，**用户不应直接编辑此文件**，因为它通常由工具自动生成。真正的配置源是 `/etc/default/grub` 和 `/etc/grub.d/` 目录下的脚本。

#### 1. 关键配置参数

- **`GRUB_DEFAULT`**：指定默认启动项。可以是数字（从0开始）或菜单项名称（如“Windows Boot Manager”）。
- **`GRUB_TIMEOUT`**：启动菜单显示时间（秒），设为0则自动启动默认项。
- **`GRUB_CMDLINE_LINUX`**：传递给Linux内核的启动参数，如`nomodeset`用于解决显卡驱动问题。
- **`GRUB_DISABLE_OS_PROBER`**：若设为`false`，GRUB将自动扫描其他操作系统（如Windows）并生成启动项。

#### 2. 操作系统探测机制

GRUB通过**os-prober**工具扫描磁盘上的其他操作系统。例如，当检测到NTFS分区中存在Windows的`/EFI/Microsoft/Boot/bootmgfw.efi`时，会自动生成一个启动项，指向该EFI文件。这一机制是双系统无缝切换的关键。

**案例**：在一台安装Ubuntu和Windows 11的计算机上，运行`sudo update-grub`后，GRUB会执行os-prober，发现Windows分区，并在`grub.cfg`中生成如下条目：

```bash
menuentry 'Windows Boot Manager (on /dev/nvme0n1p1)' {
    search --fs-uuid --set=root 1234-5678
    chainloader /EFI/Microsoft/Boot/bootmgfw.efi
}
```

这里，`chainloader`指令表示将控制权交给Windows的引导程序，实现“链式引导”。

---

### 三、双系统中的“命运抉择”：GRUB如何管理优先级

在多系统环境中，GRUB的启动逻辑并非固定不变，而是受多种因素影响：

#### 1. 默认启动项的“惯性”

系统通常会在上一次成功启动的操作系统上停留`GRUB_TIMEOUT`秒。如果用户未选择，将自动启动默认项。这一机制可能导致用户“意外”进入Linux，而忘记切换回Windows。

**解决方案**：在`/etc/default/grub`中设置`GRUB_DEFAULT=saved`，并配合`GRUB_SAVEDEFAULT=true`，使GRUB记住用户上次的选择。

#### 2. 时间敏感场景：快速切换

开发者常需在Linux下编译代码，在Windows下运行测试。若每次启动都需等待GRUB菜单，效率极低。此时可：

- 设置`GRUB_TIMEOUT=0`，但保留一个快捷键（如`Esc`或`Shift`）进入菜单。
- 使用`grub-reboot`命令临时更改下一次启动项：

```bash
sudo grub-reboot 2  # 下一次启动第三项（从0开始）
sudo reboot
```

此方法不修改配置文件，仅影响单次启动。

#### 3. 安全启动（Secure Boot）的挑战

UEFI的Secure Boot功能要求所有引导程序必须由可信证书签名。Windows的引导程序已签名，但GRUB的签名状态因发行版而异。例如：

- Ubuntu、Fedora等主流发行版使用**Microsoft签名的shim**，可兼容Secure Boot。
- 某些自定义内核或第三方发行版可能未签名，导致GRUB无法加载。

此时，用户需在UEFI设置中禁用Secure Boot，或使用已签名的GRUB版本。

---

### 四、故障排查：当GRUB“罢工”时

双系统配置中，GRUB故障是最常见的问题之一。典型表现包括：

- **黑屏无菜单**：可能是`GRUB_TIMEOUT=0`且无快捷键。
- **直接进入Windows**：Windows更新可能覆盖GRUB为默认引导程序。
- **GRUB rescue模式**：文件系统损坏或GRUB安装路径错误。

#### 1. 恢复GRUB控制权

若Windows更新后GRUB丢失，可使用Linux Live USB恢复：

1. 启动Live系统，挂载原Linux根分区。
2. 挂载ESP分区（通常为`/dev/sda1`或`/dev/nvme0n1p1`）。
3. 重新安装GRUB：

```bash
sudo grub-install --target=x86_64-efi --efi-directory=/boot/efi --bootloader-id=GRUB
sudo update-grub
```

此命令将GRUB重新注册为UEFI默认引导项。

#### 2. 修复GRUB rescue模式

在rescue模式下，需手动加载模块和配置文件：

```bash
set prefix=(hd0,gpt5)/boot/grub
set root=(hd0,gpt5)
insmod normal
normal
```

成功后，可进入系统并运行`update-grub`修复配置。

---

### 五、高级技巧：自定义与优化

GRUB不仅是一个工具，更是一个可编程的启动平台。高级用户可：

- **美化启动菜单**：使用`grub-customizer`工具调整字体、背景、高亮颜色。
- **加密GRUB菜单**：通过`GRUB_PASSWORD`防止未授权修改启动参数。
- **支持网络启动**：在服务器环境中，GRUB可加载PXE配置，实现无盘启动。

此外，**Btrfs/ZFS等高级文件系统**的支持也依赖GRUB模块。例如，ZFS需要加载`zfs`模块才能识别根分区。

---

### 总结

GRUB是双系统启动的“大脑”，它通过灵活的配置、智能的操作系统探测和强大的链式引导机制，决定了计算机在启动时的“命运”。它不仅是Linux的引导程序，更是多系统生态的协调者。理解GRUB的工作原理，不仅有助于解决启动问题，更能让用户真正掌控自己的系统环境。

从BIOS/UEFI的初始握手，到`grub.cfg`中的菜单项生成，再到`chainloader`将控制权交给Windows，每一个步骤都体现了开源社区在系统底层设计上的智慧。GRUB的“命运抉择”机制，既体现了技术复杂性，也展现了用户友好性——它允许你自由切换，也允许你设置默认路径；它支持自动化，也保留手动干预的入口。

在未来，随着UEFI、Secure Boot、TPM等安全机制的普及，GRUB的角色将更加重要。掌握GRUB，就是掌握操作系统启动的“钥匙”。无论你是一名开发者、系统管理员，还是普通用户，理解GRUB，就是理解计算机启动的本质——它不仅是技术的体现，更是用户与机器之间信任与控制的桥梁。