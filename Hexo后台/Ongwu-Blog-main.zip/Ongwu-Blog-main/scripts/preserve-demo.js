/* global hexo */
'use strict';

// 此脚本已被禁用，链接修复功能已移至fix-links.js
// 保留此文件仅作为备份

/*
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// 注册after_generate过滤器，在Hexo生成后执行
hexo.extend.filter.register('after_generate', function() {
  const publicDir = hexo.public_dir;
  const demoSrc = path.join(hexo.base_dir, 'demo/blog');
  const demoDest = path.join(publicDir, 'demo/blog');
  
  // 检查demo/blog源目录是否存在
  if (fs.existsSync(demoSrc)) {
    try {
      console.log('Preserving demo/blog directory...');
      
      // 确保public/demo目录存在
      if (!fs.existsSync(path.dirname(demoDest))) {
        fs.mkdirSync(path.dirname(demoDest), { recursive: true });
      }
      
      // 如果目标目录已存在，先删除它
      if (fs.existsSync(demoDest)) {
        if (process.platform === 'win32') {
          // Windows系统
          execSync(`rmdir /s /q "${demoDest}"`);
        } else {
          // Unix-like系统
          execSync(`rm -rf "${demoDest}"`);
        }
      }
      
      // 复制整个demo/blog目录
      if (process.platform === 'win32') {
        // Windows系统
        execSync(`xcopy "${demoSrc}" "${demoDest}" /E /I /H /Y`);
      } else {
        // Unix-like系统
        execSync(`cp -r "${demoSrc}" "${demoDest}"`);
      }
      
      console.log('Demo/blog directory preserved successfully.');
    } catch (err) {
      console.error('Failed to preserve demo/blog directory:', err);
    }
  }
});
*/