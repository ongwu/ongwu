/* global hexo */
'use strict';

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// 已修改为处理demo/Ongwu-Reveal和demo/Ongwu-Simple目录
console.log('fix-links.js 已加载，准备处理demo目录下的网站链接...');

// 注册after_generate过滤器，在Hexo生成后执行
hexo.extend.filter.register('after_generate', function() {
  const publicDir = hexo.public_dir;
  const baseDir = hexo.base_dir;
  
  console.log('after_generate过滤器已触发，开始处理链接...');
  console.log('public目录路径:', publicDir);
  
  // 定义需要处理的demo子目录
  const demoSubdirs = ['Ongwu-Reveal', 'Ongwu-Simple'];
  
  // 处理每个demo子目录
  demoSubdirs.forEach(subdir => {
    try {
      // 源目录路径
      const demoSrc = path.join(baseDir, 'demo', subdir);
      // 目标目录路径
      const demoDest = path.join(publicDir, 'demo', subdir);
      
      console.log(`\n====== 开始处理demo/${subdir}目录 ======`);
      
      // 检查源目录是否存在
      if (!fs.existsSync(demoSrc)) {
        console.warn(`警告: 源目录 ${demoSrc} 不存在，跳过处理`);
        return;
      }
      
      // 确保public/demo目录存在
      if (!fs.existsSync(path.dirname(demoDest))) {
        fs.mkdirSync(path.dirname(demoDest), { recursive: true });
        console.log(`已创建目录: ${path.dirname(demoDest)}`);
      }
      
      // 复制demo子目录到public目录
      copyDirectory(demoSrc, demoDest);
      
      // 修复链接
      if (fs.existsSync(demoDest)) {
        console.log(`开始修复demo/${subdir}目录中的链接...`);
        fixLinksInDemoDir(demoDest, `demo/${subdir}`);
        console.log(`demo/${subdir}目录链接修复完成！`);
      }
      
    } catch (err) {
      console.error(`处理demo/${subdir}目录失败:`, err);
    }
  });
  
  console.log('\n所有demo目录链接修复处理完成！');
});

/**
 * 复制目录
 */
function copyDirectory(src, dest) {
  console.log(`正在复制目录: ${src} -> ${dest}`);
  
  // 确保目标目录不存在或先删除它
  if (fs.existsSync(dest)) {
    if (process.platform === 'win32') {
      // Windows系统
      execSync(`rmdir /s /q "${dest}"`, { stdio: 'ignore' });
    } else {
      // Unix-like系统
      execSync(`rm -rf "${dest}"`, { stdio: 'ignore' });
    }
  }
  
  // 创建目标目录
  fs.mkdirSync(dest, { recursive: true });
  
  // 复制文件
  if (process.platform === 'win32') {
    // Windows系统 - 修复嵌套目录问题
    execSync(`xcopy "${src}" "${dest}" /E /I /H /Y`, { stdio: 'ignore' });
  } else {
    // Unix-like系统
    execSync(`cp -r "${src}"/* "${dest}"`, { stdio: 'ignore' });
  }
  
  console.log(`目录复制完成: ${src} -> ${dest}`);
}

/**
 * 修复demo子目录中的链接
 */
function fixLinksInDemoDir(demoDir, basePath) {
  // 遍历demo子目录下的所有HTML文件
  traverseDirectory(demoDir, (filePath) => {
    if (path.extname(filePath) === '.html') {
      fixLinksInFile(filePath, basePath);
    }
  });
}

/**
 * 遍历目录
 */
function traverseDirectory(dir, callback) {
  // 检查目录是否存在
  if (!fs.existsSync(dir)) {
    console.warn(`警告: 目录 ${dir} 不存在，跳过遍历`);
    return;
  }
  
  const files = fs.readdirSync(dir);
  
  files.forEach(file => {
    const fullPath = path.join(dir, file);
    
    try {
      const stats = fs.statSync(fullPath);
      
      if (stats.isDirectory()) {
        traverseDirectory(fullPath, callback);
      } else {
        callback(fullPath);
      }
    } catch (err) {
      console.error(`访问文件/目录失败 ${fullPath}:`, err);
    }
  });
}

/**
 * 修复单个文件中的链接
 */
function fixLinksInFile(filePath, basePath) {
  try {
    console.log(`\n处理文件: ${filePath}`);
    let content = fs.readFileSync(filePath, 'utf8');
    
    // 1. 处理所有以/开头的链接（包括CSS、JS等资源文件）
    const rootLinkPattern = /(href|src)="\/([^"'#?]*)"/g;
    let modifiedContent = content.replace(rootLinkPattern, `$1="/${basePath}/$2"`);
    
    // 1.1 专门处理包含../的链接，如 /demo/Ongwu-Simple/../css/bootstrap.min.css
    const parentPathPattern = new RegExp(`(href|src)="/${basePath}\/\.\.\/([^"'#?]*)"`, 'g');
    modifiedContent = modifiedContent.replace(parentPathPattern, `$1="/${basePath}/$2"`);
    
    // 2. 处理相对路径链接，如 <a href="Hexo/">、<a href="categories/"> 等
    // 注意：只匹配不以/开头且不包含http/https的链接
    const relativePathPattern = /href="([^"'\/][^"]*)"/g;
    modifiedContent = modifiedContent.replace(relativePathPattern, (match, p1) => {
      // 跳过已包含协议的链接（如http://, https://）
      if (p1.startsWith('http://') || p1.startsWith('https://')) {
        return match;
      }
      
      // 对于相对路径，添加基础路径前缀
      return `href="/${basePath}/${p1}"`;
    });
    
    // 3. 处理CSS链接，如 <link href="../css/bootstrap.min.css"> 或 <link href="../../css/bootstrap.min.css">
    const cssLinkPattern = /href="((\.\.\/)+)(css\/[^"']*\.css)"/g;
    modifiedContent = modifiedContent.replace(cssLinkPattern, (match, p1, p2, p3) => {
      // 提取CSS文件名
      const cssFileName = path.basename(p3);
      return `href="/${basePath}/css/${cssFileName}"`;
    });
    
    // 3.1 处理格式为 href="/demo/Ongwu-Simple/../../css/xxx.css" 的CSS链接
    const badCssPattern4 = new RegExp(`href="/${basePath}\/\.\.\/\.\.\/css\/([^"']*)"`, 'g');
    modifiedContent = modifiedContent.replace(badCssPattern4, `href="/${basePath}/css/$1"`);
    
    // 3.2 处理格式为 rel="stylesheet" href="/demo/Ongwu-Simple/../../css/xxx.css" 的CSS链接
    const badCssPattern5 = new RegExp(`rel="stylesheet" href="/${basePath}\/\.\.\/\.\.\/css\/([^"']*)"`, 'g');
    modifiedContent = modifiedContent.replace(badCssPattern5, `rel="stylesheet" href="/${basePath}/css/$1"`);
    
    // 4. 处理JS链接，如 <script src="../js/main.js"> 或 <script src="../../js/main.js">
    const jsLinkPattern = /src="((\.\.\/)+)(js\/[^"']*\.js)"/g;
    modifiedContent = modifiedContent.replace(jsLinkPattern, (match, p1, p2, p3) => {
      // 提取JS文件名
      const jsFileName = path.basename(p3);
      return `src="/${basePath}/js/${jsFileName}"`;
    });
    
    // 5. 处理图标文件链接，如 <link rel="icon" href="../favicon.ico"> 或 <link rel="icon" href="../../favicon.ico">
    const faviconPattern = /href="((\.\.\/)+)favicon\.ico"/g;
    modifiedContent = modifiedContent.replace(faviconPattern, `href="/${basePath}/favicon.ico"`);
    
    // 6. 处理RSS链接，如 <link rel="alternate" type="application/rss+xml" title="ONGWU BLOG" href="../atom.xml"> 或 <link rel="alternate" type="application/rss+xml" title="ONGWU BLOG" href="../../atom.xml">
    const rssPattern = /href="((\.\.\/)+)atom\.xml"/g;
    modifiedContent = modifiedContent.replace(rssPattern, `href="/${basePath}/atom.xml"`);
    
    // 7. 专门处理格式为 /demo/Ongwu-Simple/../css/ 的路径（修复所有链接类型）
    const badPathPattern = new RegExp(`(href|src)="/${basePath}\/\.\.\/css\/([^"'#?]*)"`, 'g');
    modifiedContent = modifiedContent.replace(badPathPattern, `$1="/${basePath}/css/$2"`);
    
    // 8. 专门处理格式为 /demo/Ongwu-Simple/../favicon.ico 的路径
    const badFaviconPattern = new RegExp(`href="/${basePath}\/\.\.\/favicon\.ico"`, 'g');
    modifiedContent = modifiedContent.replace(badFaviconPattern, `href="/${basePath}/favicon.ico"`);
    
    // 9. 专门处理格式为 /demo/Ongwu-Simple/../atom.xml 的路径
    const badAtomPattern = new RegExp(`href="/${basePath}\/\.\.\/atom\.xml"`, 'g');
    modifiedContent = modifiedContent.replace(badAtomPattern, `href="/${basePath}/atom.xml"`);
    
    // 10. 处理相对路径的JS文件引用，如 src="js/main.js"
    const relativeJsPattern = /src="js\/([^"']*)"/g;
    modifiedContent = modifiedContent.replace(relativeJsPattern, `src="/${basePath}/js/$1"`);
    
    // 11. 处理搜索功能中的search.xml相对路径（两种格式）
    // 格式1: searchFunc('search.xml', 'searchInput', 'searchResult');
    const searchXmlPattern1 = /searchFunc\('search\.xml', 'searchInput', 'searchResult'\);/g;
    modifiedContent = modifiedContent.replace(searchXmlPattern1, `searchFunc('/${basePath}/search.xml', 'searchInput', 'searchResult');`);
    
    // 格式2: searchFunc('../../search.xml', 'searchInput', 'searchResult')
    const searchXmlPattern2 = /searchFunc\('\.\.\/\.\.\/search\.xml', 'searchInput', 'searchResult'\)/g;
    modifiedContent = modifiedContent.replace(searchXmlPattern2, `searchFunc('/${basePath}/search.xml', 'searchInput', 'searchResult')`);
    
    // 12. 处理格式为 /demo/Ongwu-Simple/../ 的链接，修复首页链接跳转问题
    const parentDirLinkPattern = new RegExp(`href="/${basePath}\/\.\.\/"`, 'g');
    modifiedContent = modifiedContent.replace(parentDirLinkPattern, `href="/${basePath}/"`);
    
    // 13. 处理格式为 /demo/Ongwu-Simple/../links/ 的链接，修复友链链接跳转问题
    const linksDirLinkPattern = new RegExp(`href="/${basePath}\/\.\.\/links/"`, 'g');
    modifiedContent = modifiedContent.replace(linksDirLinkPattern, `href="/${basePath}/links/"`);
    
    // 14. 处理格式为 /demo/Ongwu-Simple/../about/ 的链接，修复关于页面链接跳转问题
    const aboutDirLinkPattern = new RegExp(`href="/${basePath}\/\.\.\/about/"`, 'g');
    modifiedContent = modifiedContent.replace(aboutDirLinkPattern, `href="/${basePath}/about/"`);
    
    // 15. 处理格式为 /demo/Ongwu-Simple/../../ 的链接，修复首页链接跳转问题
    const rootDirLinkPattern = new RegExp(`href="/${basePath}\/\.\.\/\.\.\/"`, 'g');
    modifiedContent = modifiedContent.replace(rootDirLinkPattern, `href="/${basePath}/"`);
    
    // 16. 处理格式为 /demo/tags/ 的链接，修复标签页面链接跳转问题
    const tagsLinkPattern = new RegExp(`href="/demo/tags/"`, 'g');
    modifiedContent = modifiedContent.replace(tagsLinkPattern, `href="/${basePath}/tags/"`);
    
    // 17. 处理格式为 /demo/categories/ 的链接，修复分类页面链接跳转问题
    const categoriesLinkPattern = new RegExp(`href="/demo/categories/"`, 'g');
    modifiedContent = modifiedContent.replace(categoriesLinkPattern, `href="/${basePath}/categories/"`);
    
    // 保存修改后的内容
    fs.writeFileSync(filePath, modifiedContent, 'utf8');
    console.log(`已修复链接并保存文件: ${filePath}`);
  } catch (err) {
    console.error(`修复文件链接失败 ${filePath}:`, err);
  }
}